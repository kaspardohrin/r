
remove_columns <- function(wish) {
  wish <<- subset(wish, select = -c(title, shipping_option_name, shipping_option_price, shipping_is_express, merchant_has_profile_picture, merchant_profile_picture))
}

correct_colors <- function(wish) {
  wish$product_color[wish$product_color == "Blue"] <- "blue"
  wish$product_color[wish$product_color == "prussianblue"] <- "blue"
  wish$product_color[wish$product_color == "denimblue"] <- "blue"
  wish$product_color[wish$product_color == "navy blue"] <- "blue"
  wish$product_color[wish$product_color == "darkblue"] <- "blue"
  wish$product_color[wish$product_color == "lakeblue"] <- "blue"
  wish$product_color[wish$product_color == "navy"] <- "blue"
  wish$product_color[wish$product_color == "navyblue"] <- "blue"
  wish$product_color[wish$product_color == "skyblue"] <- "blue"
  wish$product_color[wish$product_color == "lightblue"] <- "blue"
  wish$product_color[wish$product_color == "blue & pink"] <- "blue"
  wish$product_color[wish$product_color == "navyblue & white"] <- "blue"
  wish$product_color[wish$product_color == "skyblue"] <- "blue"

  wish$product_color[wish$product_color == "White"] <- "white"
  wish$product_color[wish$product_color == "offwhite"] <- "white"
  wish$product_color[wish$product_color == "whitestripe"] <- "white"
  wish$product_color[wish$product_color == "blackwhite"] <- "white"
  wish$product_color[wish$product_color == "white & red"] <- "white"
  wish$product_color[wish$product_color == "white & green"] <- "white"
  wish$product_color[wish$product_color == "white & black"] <- "white"

  wish$product_color[wish$product_color == "RED"] <- "red"
  wish$product_color[wish$product_color == "Rose red"] <- "red"
  wish$product_color[wish$product_color == "Rose red"] <- "red"
  wish$product_color[wish$product_color == "coralred"] <- "red"
  wish$product_color[wish$product_color == "rosered"] <- "red"
  wish$product_color[wish$product_color == "rose"] <- "red"
  wish$product_color[wish$product_color == "lightred"] <- "red"
  wish$product_color[wish$product_color == "wine red"] <- "red"
  wish$product_color[wish$product_color == "wine"] <- "red"
  wish$product_color[wish$product_color == "claret"] <- "red"
  wish$product_color[wish$product_color == "burgundy"] <- "red"
  wish$product_color[wish$product_color == "winered & yellow"] <- "red"
  wish$product_color[wish$product_color == "whinered"] <- "red"
  wish$product_color[wish$product_color == "red & blue"] <- "red"
  wish$product_color[wish$product_color == "winered"] <- "red"

  wish$product_color[wish$product_color == "Pink"] <- "pink"
  wish$product_color[wish$product_color == "lightpink"] <- "pink"
  wish$product_color[wish$product_color == "dustypink"] <- "pink"
  wish$product_color[wish$product_color == "pink & white"] <- "pink"
  wish$product_color[wish$product_color == "pink & blue"] <- "pink"
  wish$product_color[wish$product_color == "pink & black"] <- "pink"
  wish$product_color[wish$product_color == "pink & grey"] <- "pink"

  wish$product_color[wish$product_color == "orange & camouflage"] <- "orange"
  wish$product_color[wish$product_color == "apricot"] <- "orange"
  wish$product_color[wish$product_color == "orange-red"] <- "orange"

  wish$product_color[wish$product_color == "fluorescentgreen"] <- "green"
  wish$product_color[wish$product_color == "darkgreen"] <- "green"
  wish$product_color[wish$product_color == "lightkhaki"] <- "green"
  wish$product_color[wish$product_color == "applegreen"] <- "green"
  wish$product_color[wish$product_color == "army green"] <- "green"
  wish$product_color[wish$product_color == "lightgreen"] <- "green"
  wish$product_color[wish$product_color == "light green"] <- "green"
  wish$product_color[wish$product_color == "khaki"] <- "green"
  wish$product_color[wish$product_color == "Army green"] <- "green"
  wish$product_color[wish$product_color == "armygreen"] <- "green"
  wish$product_color[wish$product_color == "army"] <- "green"
  wish$product_color[wish$product_color == "mintgreen"] <- "green"

  wish$product_color[wish$product_color == "offblack"] <- "black"
  wish$product_color[wish$product_color == "Black"] <- "black"
  wish$product_color[wish$product_color == "coolblack"] <- "black"
  wish$product_color[wish$product_color == "black & green"] <- "black"
  wish$product_color[wish$product_color == "black & white"] <- "black"
  wish$product_color[wish$product_color == "black & yellow"] <- "black"
  wish$product_color[wish$product_color == "black & stripe"] <- "black"
  wish$product_color[wish$product_color == "black & blue"] <- "black"

  wish$product_color[wish$product_color == "camel"] <- "beige"
  wish$product_color[wish$product_color == "ivory"] <- "beige"
  wish$product_color[wish$product_color == "tan"] <- "beige"
  wish$product_color[wish$product_color == "nude"] <- "beige"

  wish$product_color[wish$product_color == "coffee"] <- "brown"
  wish$product_color[wish$product_color == "brown & yellow"] <- "brown"

  wish$product_color[wish$product_color == "lightgrey"] <- "gray"
  wish$product_color[wish$product_color == "grey"] <- "gray"
  wish$product_color[wish$product_color == "gray & white"] <- "gray"
  wish$product_color[wish$product_color == "lightgray"] <- "gray"

  wish$product_color[wish$product_color == "lightyellow"] <- "yellow"

  wish$product_color[wish$product_color == "violet"] <- "purple"
  wish$product_color[wish$product_color == "lightpurple"] <- "purple"

  wish$product_color[wish$product_color == "rainbow"] <- "multicolor"
  wish$product_color[wish$product_color == "floral"] <- "multicolor"
  wish$product_color[wish$product_color == "greysnakeskinprint"] <- "multicolor"
  wish$product_color[wish$product_color == "whitefloral"] <- "multicolor"
  wish$product_color[wish$product_color == "jasper"] <- "multicolor"
  wish$product_color[wish$product_color == "leopardprint"] <- "multicolor"
  wish$product_color[wish$product_color == "star"] <- "multicolor"
  wish$product_color[wish$product_color == "leopard"] <- "multicolor"
  wish$product_color[wish$product_color == "camouflage"] <- "multicolor"

  wish$product_color[wish$product_color == "rosegold"] <- "metalen"
  wish$product_color[wish$product_color == "gold"] <- "metalen"
  wish$product_color[wish$product_color == "silver"] <- "metalen"

  wish$product_color[wish$product_color == ""] <- "other"
}

createUnitSoldLabelColumn <- function() {
  wish$unit_sold_label[(wish$units_sold > 1) & (wish$units_sold < 100)] <- 1
  wish$unit_sold_label[(wish$units_sold >= 100) & (wish$units_sold < 1000)] <- 2
  wish$unit_sold_label[(wish$units_sold >= 1000) & (wish$units_sold < 5000)] <- 3
  wish$unit_sold_label[wish$units_sold >= 5000] <- 4
}

createRatingLabelColumn <- function() {
  wish$rating_label[(wish$rating > 1) & (wish$rating < 3.540)] <- 1
  wish$rating_label[(wish$rating >= 3.540) & (wish$rating < 3.840)] <- 2
  wish$rating_label[(wish$rating >= 3.808) & (wish$rating < 4.100)] <- 3
  wish$rating_label[wish$rating >= 4.100] <- 4
}

# mean of rating label en quality label
wish$mean_rating_unitssold <- (wish$rating_label + wish$units_sold_label) /2
tmdb.movies$genres <- jq(tmdb.movies$genres, ".result.name")

install.packages("jqr")

# list in list
jq(wish$image_tags[1], ".result.tags[1].tag")

i = 1
for(product in wish$image_tags) {
  i <- i + 1;
  wish$image_tags_list <- list();
}

createRatingLabelColumn()
createQualityLabelColumn(wish)
remove_columns(wish)
correct_colors(wish)
